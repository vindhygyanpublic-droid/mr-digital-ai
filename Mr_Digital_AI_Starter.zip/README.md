# Mr Digital AI — beginner-friendly starter

This project includes:
- A responsive dark blue/purple AI chat interface
- An AI website builder that generates a self-contained HTML draft and previews it
- A small Node.js server so the API key is **not placed in browser JavaScript**

## Important before you start
The interface can be previewed without an API key, but real AI responses need an AI provider API key and may incur usage charges. ChatGPT subscriptions and API billing are separate. Ask a parent/guardian to help with account and billing setup if you are under 18. Never share an API key publicly or put it into `public/index.html`.

## Run locally on Windows
1. Install Node.js LTS from https://nodejs.org/ (if not already installed).
2. Extract this ZIP to a folder.
3. Open that folder in Terminal / Command Prompt.
4. Run `npm install`
5. Copy `.env.example` to a new file named `.env`.
6. Open `.env` and replace `put_your_api_key_here` with your API key from https://platform.openai.com/api-keys
7. Run `npm start`
8. Open http://localhost:3000 in your browser.

If you don't add an API key, the website loads but chat and generation show a setup message. Do not upload `.env` or share your API key.

## Hosting
The frontend and server must both run for real AI features. Static hosting such as a plain drag-and-drop site host can publish only the interface, not this Node server. To publish the complete app, use a host that supports Node.js server applications and set `OPENAI_API_KEY` in that host's private environment-variable settings. Free hosting availability and limits can change, and AI API usage may cost money. Do not commit `.env` to GitHub.

## Safety and limitations
- This is a starter project, not a finished commercial service.
- Add rate limits, authentication, usage caps, privacy disclosures, and abuse protection before sharing publicly.
- Generated HTML is a draft. Review it before publishing. The preview iframe is sandboxed, but do not treat generated code as automatically trustworthy.
- Don't collect passwords, payment card data, or sensitive personal information in generated websites.
