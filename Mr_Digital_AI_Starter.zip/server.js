require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI is not connected yet. Add your API key to the .env file, then restart the app." });
    }
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 8000) return res.status(400).json({ error: "Please keep your message under 8,000 characters." });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are Mr Digital AI, a friendly, clear assistant. Help with learning, writing, brainstorming, coding, and website creation. For website requests, return a complete self-contained HTML document with embedded CSS and JavaScript, no external dependencies, and no explanations outside the HTML. Do not claim to publish or host a website." },
        { role: "user", content: message }
      ],
      temperature: 0.7
    });
    res.json({ reply: response.choices[0]?.message?.content || "I couldn't create a response. Please try again." });
  } catch (err) {
    console.error("AI request failed:", err.message);
    res.status(500).json({ error: "The AI request failed. Check your API key, account access, and usage limits." });
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Mr Digital AI is running at http://localhost:${port}`));